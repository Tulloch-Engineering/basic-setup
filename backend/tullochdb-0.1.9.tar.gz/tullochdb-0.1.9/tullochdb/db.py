import logging
import os
import struct
from typing import Dict
from typing import List

import requests
from sqlalchemy import Connection
from sqlalchemy import MetaData
from sqlalchemy import Table
from sqlalchemy import create_engine
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

INCOMPATIBLE_ERROR = "The arguments passed are incompatible."


class TullochDatabaseTool:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.engine = None
        self.schema = None

    def startup(
        self,
        db_type: str = None,
        username: str = None,
        password: str = None,
        host: str = None,
        port: str = None,
        database: str = None,
        driver: str = None,
        schema: str = None,
        connection_string: str = None,
    ) -> None:
        """
        Starts the database engine. Sets the engine to the TullochDatabaseTool.engine.

        :param db_type: The type of the database (e.g., 'mssql').
        :param username: The database username.
        :param password: The database password.
        :param host: The database host.
        :param port: The database port.
        :param database: The database name.
        :param driver: The database driver.
        :param connection_string: Assume connection is to a server and use the secondary version

        :return: None
        :raises SQLAlchemyError: If there is a SQLAlchemy error.
        :raises Exception: Any generic error that is raised.
        """
        try:
            connect_args = {}
            if connection_string:  # Used when connecting to sql server
                # get token either stored in env or ~/.db_key/database_key.txt file
                file_path = os.path.expanduser("~/.db_key/database_key.txt")

                tenant_id = os.environ.get("TENANT_ID")
                client_id = os.environ.get("CLIENT_ID")
                client_secret = os.environ.get("CLIENT_SECRET")
                token = os.environ.get("DBA_KEY")

                if token is None and all([tenant_id, client_id, client_secret]):
                    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

                    # Prepare the data for the POST request
                    data = {
                        "grant_type": "client_credentials",
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "scope": "https://database.windows.net/.default",
                    }

                    # Make the request to get the token
                    response = requests.post(token_url, data=data)

                    # Check if the request was successful
                    if response.status_code == 200:
                        token = response.json()
                        token = token.get("access_token")
                    else:
                        raise Exception(f"Failed to get access token: {response.status_code} {response.text}")

                elif token is None:
                    if os.path.isfile(file_path):
                        with open(file_path, "r") as file:
                            token = file.read().strip()
                    else:
                        raise Exception("No Token Available!")

                token_bytes = token.encode("UTF-16-LE")
                token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)
                connect_args = {
                    "attrs_before": {1256: token_struct}
                }  # This connection option is defined by Microsoft in msodbcsql.h
                db_url = f"mssql+pyodbc:///?odbc_connect={connection_string}"
            else:
                db_url = f"{db_type}://{username}:{password}@{host},{port}/{database}?driver={driver}"
            self.engine = create_engine(db_url, connect_args=connect_args)
            self.engine.connect()

            if schema:
                self.schema = schema

            self.logger.info("Engine Startup successful")
        except (SQLAlchemyError, Exception) as e:
            self.logger.error(e)
            raise

    def set_schema(self, connection: Connection):
        if self.schema:
            val = connection.execute(text("SELECT USER_NAME()"))
            username = val.fetchone()[0]
            connection.execute(text(f"ALTER USER [{username}] WITH DEFAULT_SCHEMA = [{self.schema}]"))

    def execute_query(self, query: str):
        """
        Executes SQL to read data from database.

        :param query: Sequel string that will be executed.

        :return: Dict of results.
        :raises AttributeError: If columns and data do not have the same length, or if data contains unknown columns.
        :raises SQLAlchemyError: If there is a SQLAlchemy error.
        """
        try:
            with self.engine.begin() as connection:
                self.set_schema(connection)
                result = connection.execute(text(query))
                columns = result.keys()
                rows = result.fetchall()
                # Convert rows to list of dicts
                results = [dict(zip(columns, row)) for row in rows]

            return results

        except (SQLAlchemyError, Exception) as e:
            self.logger.error(e)
            raise

    def execute_sql(self, query: str, params: None | dict | list = None, fetch: bool | None = False):
        """
        Executes SQL to create, update, and delete.

        :param query: Sequel string that will be executed.
        :param params: Optional dictionary which defines the input of the sequel.
        :param fetch: Optional boolean value to define if the execution will return the rowcount (default) or a value from one of the inputted column (used for receiving generated id).

        :return: The number of columns adjusted.
        :raises AttributeError: If columns and data do not have the same length, or if data contains unknown columns.
        :raises SQLAlchemyError: If there is a SQLAlchemy error.
        """
        try:
            with self.engine.begin() as connection:
                self.set_schema(connection)
                result = connection.execute(text(query), params) if params else connection.execute(text(query))

                if fetch:
                    if fetched_value := result.fetchone():
                        return fetched_value[0]
                    raise Exception("fetchone error")
                elif isinstance(
                    params, list
                ):  # I know this is bad practice but I still want the functionality for now.
                    # TODO: They will update this in the future!
                    return len(params)

                return result.rowcount

        except (AttributeError, Exception) as e:
            self.logger.error(e)
            raise

    def insert_row(self, table_name: str, columns: List[str], data: List[str]):
        """
        Inserts a row into a specified table and returns the number of columns inserted.

        :param table_name: The name of the table to insert data into.
        :param columns: A list of column names.
        :param data: A list of entries corresponding to the columns.

        :return: None.
        :raises AttributeError: If columns and data do not have the same length, or if data contains unknown columns.
        :raises SQLAlchemyError: If there is a SQLAlchemy error.
        """
        try:
            if len(columns) != len(data):
                raise ValueError(INCOMPATIBLE_ERROR)

            metadata = MetaData()
            table = Table(table_name, metadata, autoload_with=self.engine)

            # formatted as zip to comply with sqlalchemy format.
            prepared_data = dict(zip(columns, data))

            with self.engine.begin() as connection:
                self.set_schema(connection)
                connection.execute(table.insert().values(prepared_data))

        except (AttributeError, SQLAlchemyError) as e:
            self.logger.error(e)
            raise

    def insert_rows(self, table_name: str, columns: List[str], data: List[Dict[str, str]]) -> int:
        """
        Inserts rows into a specified table and returns the number of rows inserted.

        :param table_name: The name of the table to insert data into.
        :param columns: A list of column names.
        :param data: A list of dictionaries where each dictionary represents a row.

        :return: The number of rows inserted.
        :raises AttributeError: If columns and data do not have the same length, or if data contains unknown columns.
        :raises SQLAlchemyError: If there is a SQLAlchemy error.
        """
        try:
            if len(columns) != len(data[0]):
                raise ValueError(INCOMPATIBLE_ERROR)

            for row in data:
                if not all(col in row for col in columns):
                    raise ValueError(INCOMPATIBLE_ERROR)

            metadata = MetaData()
            table = Table(table_name, metadata, autoload_with=self.engine)
            prepared_data = [dict(zip(columns, row.values())) for row in data]

            with self.engine.begin() as connection:
                self.set_schema(connection)
                result = connection.execute(table.insert(), prepared_data)
                return result.rowcount

        except (AttributeError, SQLAlchemyError) as e:
            self.logger.error(e)
            raise

    def close(self) -> None:
        """
        Closes the database engine if it is running.

        :return: None
        """
        try:
            if self.engine:
                self.engine.dispose()
                self.logger.info("Engine closed successfully")
            else:
                self.logger.warning("No engine to close")
        except Exception as e:
            self.logger.error(e)
            raise
