# tullochdb

**Database Tool for Tulloch Databases**

**Version**: 0.1.8

**Python Version**: 3.11.9

## Overview

This tool provides a convenient interface for interacting with Tulloch databases. It simplifies database operations by managing connections and offering functions to execute SQL queries, insert and retrieve data, and manage database transactions efficiently.

## Usage

### Creating Data

To create data, utilize the following methods:
- `execute_sql`: Execute SQL statements directly.
- `insert_row`: Insert a single row into a database table.
- `insert_rows`: Insert rows into a database table. These functions simplify endpoint creation by handling data formatting for queries.

### Reading Data

To retrieve data, use:
- `execute_query`: Execute a SQL query and retrieve the results as a Pandas DataFrame. For guidance on handling DataFrame data, refer to [this article](https://www.scaler.com/topics/pandas/pandas-database/).

### Updating Data

For updating existing data:
- `execute_sql`: Execute SQL statements for direct updates.

### Deleting Data

To delete data, use:
- `execute_sql`: Execute SQL statements to delete data from the database.

## Downloading Package

Since this is a package, it can be installed locally using the following command:
> [!NOTE]
> Make sure to replace `X.X.X` with the updated version number
```
poetry add /path/to/your/package/dist/tullochdb-X.X.X.tar.gz
```

Ensure all versions are kept in the repository; do not delete old versions in the `dist` folder.

## Testing/Development

Testing utilizes a virtual Microsoft SQL database managed by Docker. This setup ensures a clean environment and consistent test results. To run tests with pytest, start the Docker environment using `docker-compose`:
```
docker-compose -f tests/docker-compose.yml up -d
```
Setup correct python environment (3.11.9):
```
python -m venv venv
```
```
source venv/bin/activate
```
```
pip install -r requirements.txt
```
```
pip install pytest
```

Then, execute the test suite:
```
pytest tests/unit_tests/unit_db_tests.py tests/integration_tests/integration_db_tests.py -v -s
```

To close the docker container use:
```
docker-compose down
```
### Updates

When any updates occur to the overall system one must update the pyproject.toml file. run `pip freeze` to update the poetry.lock file. Lastly update the requirements.txt file by running 
```
venv/bin/poetry export -f requirements.txt --output requirements.txt --without-hashes
``` 
Build a new version with:
```
poetry build
```
### Workflows

GitHub Actions is configured to automate linting and testing processes.
